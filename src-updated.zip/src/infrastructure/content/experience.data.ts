import type { Experience, EarlierExperience } from "@/domain/entities/experience";

export const experience: Experience[] = [
  {
    company: "Britam EA",
    title: "Apps Developer",
    period: "Jun 2023 — May 2025",
    duration: "2 yrs · Hybrid",
    bullets: [
      "Architected and shipped Britam's Financial Advisor app from scratch in Flutter, taking it from an empty repo all the way through to a live release on the App Store and Google Play.",
      "Built the core sales workflows that let field advisors track leads, log policy sales, and manage their day-to-day pipeline from their phones.",
      "Designed and built a companion NestJS admin portal that gives underwriters a fast, reliable way to review and act on incoming policy applications.",
      "Partnered directly with business stakeholders on sprint planning and feature prioritization, translating commercial goals into a well-scoped, technically sound backlog.",
      "Mentored junior developers through regular code reviews, pairing with them on Flutter architecture problems and raising the team's overall code quality.",
      "Owned releases end-to-end — versioning, store submissions, and post-launch monitoring — across both iOS and Android.",
    ],
    tags: ["Flutter", "NestJS", "Mobile", "Leadership"],
  },
  {
    company: "Pondus Ltd",
    title: "Mobile App Developer",
    period: "Jan — May 2023",
    duration: "5 mos · Remote",
    bullets: [
      "Shipped features and bug fixes across Android, iOS, and web in a fast-moving, cross-functional team.",
      "Helped drive a 30% increase in user engagement through targeted stability and UX improvements.",
      "Worked closely with QA and design to turn around fixes quickly during active release cycles.",
    ],
    tags: ["Android", "iOS", "Web"],
  },
  {
    company: "Adanian Labs",
    title: "Mobile App Developer",
    period: "Aug 2021 — Jul 2022",
    duration: "1 yr · On-site",
    bullets: [
      "Built MooveBeta, a Flutter-based micro-transaction and mobile-money platform, from the ground up.",
      "Helped deliver the platform across four markets — Kenya, Uganda, Nigeria, and South Africa — each with its own payment rails.",
      "Collaborated within a 5-developer team, owning key mobile features from design through release.",
    ],
    tags: ["Flutter", "Fintech"],
  },
  {
    company: "Grow Mobile Tech",
    title: "Desktop App Developer",
    period: "Apr 2020 — Mar 2021",
    duration: "1 yr · On-site",
    bullets: [
      "Built .NET (C#) desktop clients for two e-learning platforms, KEC App and MsingiPack.",
      "Delivered both projects on budget while optimizing local data storage for offline use.",
      "Worked directly with stakeholders to translate e-learning content requirements into working desktop software.",
    ],
    tags: [".NET", "C#"],
  },
];

export const earlierExperience: EarlierExperience[] = [
  {
    company: "Diamond Eng. Co. Ltd",
    title: "Software Developer",
    period: "Feb 2019 — Jan 2020",
    bullets: [
      "Built a customer/sales management system end-to-end (PHP REST API + Java mobile app) with a 3-person team.",
      "Liaised between engineering and management to keep delivery aligned with business needs.",
    ],
    tags: ["PHP", "Java"],
  },
  {
    company: "Kenya School of TVET",
    title: "Software Developer Intern",
    period: "Jan — Jul 2017",
    bullets: [
      "Built a Complaint Management System (PHP/JavaScript) for tracking, categorizing, and resolving institutional issues.",
    ],
    tags: ["PHP", "JavaScript"],
  },
];
