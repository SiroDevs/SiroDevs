import { Resend } from "resend";
import type { ContactMessage } from "@/domain/entities/contact-message";
import type { MessageSender } from "@/domain/repositories/message-sender";
import { site } from "@/config/site";

function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

/**
 * Delivers contact-form submissions via Resend's HTTP API — no SMTP, no
 * app-password to manage. Reads credentials from env vars at send time, so a
 * missing config fails loudly and specifically rather than as a generic 500.
 *
 * Required env vars:
 *  - RESEND_API_KEY: API key from https://resend.com/api-keys
 *  - RESEND_FROM_EMAIL: a verified sender, e.g. "Siro Portfolio <notifications@sirodevs.dev>"
 *    (falls back to Resend's shared "onboarding@resend.dev" sender, which
 *    works out of the box but is rate-limited and best for testing only)
 */
export class ResendMessageSender implements MessageSender {
  async send(message: ContactMessage): Promise<void> {
    const apiKey = process.env.RESEND_API_KEY;

    if (!apiKey) {
      throw new Error("Email service is not configured: missing RESEND_API_KEY.");
    }

    const from = process.env.RESEND_FROM_EMAIL ?? "Siro Portfolio <onboarding@resend.dev>";
    const resend = new Resend(apiKey);

    const { name, email, subject, message: body } = message;

    const { error } = await resend.emails.send({
      from,
      to: site.email,
      replyTo: email,
      subject: `[Portfolio] ${subject}`,
      text: `Name: ${name}\nEmail: ${email}\n\n${body}`,
      html: `
        <div style="font-family: sans-serif; line-height: 1.6;">
          <p><strong>Name:</strong> ${escapeHtml(name)}</p>
          <p><strong>Email:</strong> ${escapeHtml(email)}</p>
          <p><strong>Subject:</strong> ${escapeHtml(subject)}</p>
          <p><strong>Message:</strong></p>
          <p>${escapeHtml(body).replace(/\n/g, "<br />")}</p>
        </div>
      `,
    });

    if (error) {
      throw new Error(`Resend failed to send the message: ${error.message}`);
    }
  }
}
